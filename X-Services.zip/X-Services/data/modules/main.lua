sasl.options.setAircraftPanelRendering(true)
sasl.options.set3DRendering(true)
sasl.options.setInteractivity(true)

size = {4096, 4096}

panelWidth3d = 4096
panelHeight3d = 4096

components = {
  menu {};

}

X_Services_UI = contextWindow {
  name = "X-Services";
  position = { 50 , 50 , 620 , 792};
  noBackground = true ;
  proportional = false ;
  minimumSize = { 620 , 792 };
  maximumSize = { 620 , 792 };
  gravity = { 0 , 1 , 0 , 1 };
  visible = true ;
components = {
   menu {position = { 0 , 0 , 620 , 792}}
  }
}


Menu = sasl.appendMenuItem ( PLUGINS_MENU_ID , "X-Services Menu" )
Child_Menu = sasl.createMenu ( "" , PLUGINS_MENU_ID , Menu )
Append_Sub_menu = sasl.appendMenuItem ( Child_Menu, "Open/Close")

Menu_Item_State = sasl.setMenuItemState(Child_Menu, Append_Sub_menu, MENU_UNCHECKED)

if get(Menu_Item_State) == MENU_CHECKED then
   X_Services_UI:SetIsVisible(true)
  
end

