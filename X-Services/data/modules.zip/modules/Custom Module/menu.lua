test_menu_1 = sasl.appendMenuItem( PLUGINS_MENU_ID, "XS")


